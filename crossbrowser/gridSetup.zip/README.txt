Download
1. Selenium standalone (jar file)
2. Latest or specific version of browser driver (exe file)

*** happy letcoding ***